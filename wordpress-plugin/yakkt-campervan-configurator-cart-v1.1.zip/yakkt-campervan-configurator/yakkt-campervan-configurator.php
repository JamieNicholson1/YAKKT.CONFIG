<?php
/**
 * Plugin Name: Yakkt Campervan Configurator
 * Description: Custom plugin to embed the Next.js campervan configurator, add to WooCommerce cart, and process orders.
 * Version: 1.1
 * Author: Yakkt
 * Text Domain: yakkt-campervan-configurator
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Check if WooCommerce is active
 */
function yakkt_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            ?>
            <div class="error">
                <p><?php _e('Yakkt Campervan Configurator requires WooCommerce to be installed and active.', 'yakkt-campervan-configurator'); ?></p>
            </div>
            <?php
        });
        return false;
    }
    return true;
}

/**
 * Register the Shortcode [yakkt_campervan_configurator]
 * Embeds the Next.js app via an iframe
 */
function yakkt_campervan_configurator_shortcode($atts) {
    $atts = shortcode_atts(array(
        'height' => '800px',
        'width' => '100%',
    ), $atts, 'yakkt_campervan_configurator');

    // Get the configurator URL from settings or use default
    $configurator_url = get_option('yakkt_configurator_url', 'https://configurator.yakkt.com');
    
    // Generate a unique iframe ID
    $iframe_id = 'yakkt-configurator-' . uniqid();
    
    // Create the iframe HTML
    $html = sprintf(
        '<iframe id="%s" src="%s" style="width:%s; height:%s; border:none;" allow="fullscreen" title="Yakkt Campervan Configurator"></iframe>',
        esc_attr($iframe_id),
        esc_url($configurator_url),
        esc_attr($atts['width']),
        esc_attr($atts['height'])
    );
    
    return $html;
}
add_shortcode('yakkt_campervan_configurator', 'yakkt_campervan_configurator_shortcode');

/**
 * Register Custom REST API Endpoint: /wp-json/yakkt/v1/create-order
 * (Renamed to /add-to-cart for clarity, but keeping /create-order for compatibility with existing frontend if needed for now)
 * Receives JSON data, adds to cart, and returns checkout URL.
 */
function yakkt_register_rest_routes() {
    register_rest_route('yakkt/v1', '/create-order', array( // Consider renaming endpoint to /add-to-cart in future
        'methods' => 'POST',
        'callback' => 'yakkt_add_configured_item_to_cart',
        'permission_callback' => 'yakkt_verify_request', // Reusing verification
    ));
}
add_action('rest_api_init', 'yakkt_register_rest_routes');

/**
 * Verify the request (API key or other method)
 */
function yakkt_verify_request($request) {
    $api_key = $request->get_header('X-Yakkt-API-Key');
    $valid_key = get_option('yakkt_api_key', '');
    if (empty($valid_key)) return true; // Allow if no key set (dev)
    return $api_key === $valid_key;
}

/**
 * Adds the configured item to the WooCommerce cart.
 */
function yakkt_add_configured_item_to_cart($request) {
    if (!yakkt_check_woocommerce()) {
        return new WP_Error('woocommerce_missing', 'WooCommerce not installed', array('status' => 500));
    }

    $body = $request->get_json_params();

    $product_id = isset($body['productId']) ? absint($body['productId']) : 0;
    $chassis_id = isset($body['chassis']) ? sanitize_text_field($body['chassis']) : '';
    $chassis_name = isset($body['chassisName']) ? sanitize_text_field($body['chassisName']) : '';
    $components = isset($body['components']) && is_array($body['components']) ? $body['components'] : array();
    $total_price = isset($body['totalPrice']) ? floatval($body['totalPrice']) : 0.0;

    if (!$product_id || !$chassis_id || $total_price <= 0) { // Price must be > 0
        return new WP_Error('missing_data', 'Missing or invalid required data (Product ID, Chassis ID, or Total Price)', array('status' => 400));
    }

    // Ensure product exists
    $product = wc_get_product($product_id);
    if (!$product) {
        return new WP_Error('invalid_product', 'Configured product ID does not exist.', array('status' => 400));
    }
    
    // Create a detailed configuration summary for display
    $config_summary = "Configured Van: " . $chassis_name;
    $component_details_for_meta = array();
    if (!empty($components)) {
        $component_names = array();
        foreach ($components as $component) {
            if (isset($component['name'])) {
                $component_names[] = sanitize_text_field($component['name']);
                // Prepare for meta
                $component_details_for_meta[] = array(
                    'id' => isset($component['id']) ? sanitize_text_field($component['id']) : 'N/A',
                    'name' => sanitize_text_field($component['name']),
                    'price' => isset($component['price']) ? floatval($component['price']) : 0
                );
            }
        }
        if (!empty($component_names)) {
            $config_summary .= " with " . implode(', ', $component_names);
        }
    }

    // Prepare custom cart item data
    $yakkt_custom_data = array(
        '_yakkt_config_summary' => $config_summary,
        '_yakkt_total_price'    => $total_price,
        '_yakkt_chassis_id'     => $chassis_id,
        '_yakkt_chassis_name'   => $chassis_name,
        '_yakkt_components'     => $component_details_for_meta, // Store the structured array
        '_yakkt_is_configured'  => true // Flag to identify our item
    );

    try {
        // Clear the cart to ensure only the configured item is present.
        // Important: This means any existing items in the customer's cart will be removed.
        // If this is not desired, this line should be removed or made conditional.
        WC()->cart->empty_cart();

        // Add the configured product to the cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, 1, 0, array(), $yakkt_custom_data);

        if (!$cart_item_key) {
            return new WP_Error('cart_add_failed', 'Could not add configured item to cart.', array('status' => 500));
        }
        
        // Recalculate totals to apply custom price
        WC()->cart->calculate_totals();

        return new WP_REST_Response(array(
            'success' => true,
            'cartItemKey' => $cart_item_key,
            'checkoutUrl' => wc_get_checkout_url() // Standard checkout URL
        ), 200);

    } catch (Exception $e) {
        return new WP_Error('cart_exception', $e->getMessage(), array('status' => 500));
    }
}

/**
 * Set custom price for the configured item in the cart.
 */
add_action('woocommerce_before_calculate_totals', 'yakkt_set_custom_cart_item_price', 20, 1);
function yakkt_set_custom_cart_item_price($cart_obj) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    foreach ($cart_obj->get_cart() as $cart_item_key => $cart_item) {
        if (isset($cart_item['_yakkt_is_configured']) && $cart_item['_yakkt_is_configured'] === true) {
            if (isset($cart_item['_yakkt_total_price'])) {
                $cart_item['data']->set_price(floatval($cart_item['_yakkt_total_price']));
            }
        }
    }
}

/**
 * Display the custom configuration summary as the item name in cart and checkout.
 */
add_filter('woocommerce_cart_item_name', 'yakkt_display_custom_cart_item_name', 10, 3);
function yakkt_display_custom_cart_item_name($product_name, $cart_item, $cart_item_key) {
    if (isset($cart_item['_yakkt_is_configured']) && $cart_item['_yakkt_is_configured'] === true) {
        if (isset($cart_item['_yakkt_config_summary'])) {
            // Remove default product link if desired
            // $product_name = sprintf('<a href="%s">%s</a>', esc_url($cart_item['data']->get_permalink($cart_item)), $cart_item['_yakkt_config_summary']);
            return esc_html($cart_item['_yakkt_config_summary']);
        }
    }
    return $product_name;
}

/**
 * Add custom configuration data as meta to the order item.
 */
add_action('woocommerce_checkout_create_order_line_item', 'yakkt_add_custom_data_to_order_item', 10, 4);
function yakkt_add_custom_data_to_order_item($item, $cart_item_key, $values, $order) {
    if (isset($values['_yakkt_is_configured']) && $values['_yakkt_is_configured'] === true) {
        if (isset($values['_yakkt_config_summary'])) {
            $item->add_meta_data('Configuration', $values['_yakkt_config_summary'], true);
        }
        if (isset($values['_yakkt_chassis_id'])) {
            $item->add_meta_data('Chassis ID', $values['_yakkt_chassis_id'], true);
        }
        if (isset($values['_yakkt_chassis_name'])) {
            $item->add_meta_data('Chassis Name', $values['_yakkt_chassis_name'], true);
        }
        if (isset($values['_yakkt_components']) && is_array($values['_yakkt_components'])) {
            $components_string = "
"; // Start with a newline for better formatting in admin
            foreach($values['_yakkt_components'] as $component) {
                $components_string .= sprintf("- %s (£%.2f)
", esc_html($component['name']), floatval($component['price']));
            }
            $item->add_meta_data('Selected Components', $components_string, true);
        }
         if (isset($values['_yakkt_total_price'])) {
            // The price should already be set by woocommerce_before_calculate_totals hook,
            // but we can store it as meta for reference if needed.
            $item->add_meta_data('Configured Price', wc_price($values['_yakkt_total_price']), true);
        }
    }
}

/**
 * Hide quantity selector for configured item in cart (as it should always be 1)
 * And prevent metadata from showing by default (we handle name override)
 */
add_filter('woocommerce_cart_item_quantity', 'yakkt_cart_item_quantity', 10, 3 );
function yakkt_cart_item_quantity( $product_quantity, $cart_item_key, $cart_item ){
    if(isset($cart_item['_yakkt_is_configured']) && $cart_item['_yakkt_is_configured'] === true ){
        return '1'; // Display quantity as 1, not an input field
    }
    return $product_quantity;
}

add_filter( 'woocommerce_get_item_data', 'yakkt_hide_default_meta_if_configured', 10, 2 );
function yakkt_hide_default_meta_if_configured( $item_data, $cart_item ) {
    if ( isset( $cart_item['_yakkt_is_configured'] ) && $cart_item['_yakkt_is_configured'] === true ) {
        return array(); // Return empty array to hide default meta for our item
    }
    return $item_data;
}

/**
 * Add settings page for the plugin
 */
function yakkt_add_admin_menu() {
    add_options_page(
        'Yakkt Configurator Settings',
        'Yakkt Configurator',
        'manage_options',
        'yakkt-configurator',
        'yakkt_settings_page'
    );
}
add_action('admin_menu', 'yakkt_add_admin_menu');

/**
 * Register settings
 */
function yakkt_register_settings() {
    register_setting('yakkt_configurator_settings', 'yakkt_configurator_url');
    register_setting('yakkt_configurator_settings', 'yakkt_product_id');
    register_setting('yakkt_configurator_settings', 'yakkt_api_key');
}
add_action('admin_init', 'yakkt_register_settings');

/**
 * Settings page HTML
 */
function yakkt_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <p>This plugin allows embedding the Yakkt Campervan Configurator and processing its configurations through WooCommerce.</p>
        <form method="post" action="options.php">
            <?php
            settings_fields('yakkt_configurator_settings');
            do_settings_sections('yakkt_configurator_settings');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="yakkt_configurator_url">Configurator App URL</label>
                    </th>
                    <td>
                        <input type="url" id="yakkt_configurator_url" name="yakkt_configurator_url" 
                               value="<?php echo esc_attr(get_option('yakkt_configurator_url', 'https://configurator.yakkt.com')); ?>" 
                               class="regular-text">
                        <p class="description">The URL where your Next.js configurator application is hosted.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="yakkt_product_id">Base WooCommerce Product ID</label>
                    </th>
                    <td>
                        <input type="number" id="yakkt_product_id" name="yakkt_product_id" 
                               value="<?php echo esc_attr(get_option('yakkt_product_id', '')); ?>" 
                               class="regular-text">
                        <p class="description">The ID of the placeholder "Configurable Campervan" product in WooCommerce. This should match the ID set in your Next.js app's environment variables (NEXT_PUBLIC_WOOCOMMERCE_PRODUCT_ID).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="yakkt_api_key">API Key (Optional)</label>
                    </th>
                    <td>
                        <input type="text" id="yakkt_api_key" name="yakkt_api_key" 
                               value="<?php echo esc_attr(get_option('yakkt_api_key', '')); ?>" 
                               class="regular-text">
                        <p class="description">Optional API key for securing the REST endpoint. Must match the key sent by the Next.js app.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2>Important Notes:</h2>
        <ul>
            <li>Ensure the "Base WooCommerce Product ID" above matches the <code>NEXT_PUBLIC_WOOCOMMERCE_PRODUCT_ID</code> in your Vercel environment variables for the configurator app.</li>
            <li>This plugin will clear the user's cart before adding the configured item.</li>
        </ul>
    </div>
    <?php
}

/**
 * Add a Gutenberg block for the configurator
 */
function yakkt_register_block() {
    if (function_exists('register_block_type')) {
        register_block_type('yakkt/campervan-configurator', array(
            'editor_script' => 'yakkt-configurator-block',
            'render_callback' => 'yakkt_campervan_configurator_shortcode',
            'attributes' => array(
                'height' => array('type' => 'string', 'default' => '800px'),
                'width' => array('type' => 'string', 'default' => '100%'),
            ),
        ));
    }
}
add_action('init', 'yakkt_register_block');

/**
 * Enqueue block editor assets
 */
function yakkt_enqueue_block_editor_assets() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'yakkt-configurator-block',
        plugins_url('block.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime(plugin_dir_path(__FILE__) . 'block.js')
    );
}
add_action('enqueue_block_editor_assets', 'yakkt_enqueue_block_editor_assets'); 